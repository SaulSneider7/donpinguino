$(function () {

    $.ajaxSetup({
        cache: false
    });

});